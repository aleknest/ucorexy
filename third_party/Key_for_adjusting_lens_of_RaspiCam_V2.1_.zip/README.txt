                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1941802
Key for adjusting lens of RaspiCam V2.1  by Z122 is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Key for adjusting sharpness of Raspberry Pi cameras V2.1 original lenses.
This part can fit and can be hold in the window of some existing cases (like the ones in following links). Otherwise, it can also be manually holded.

Clef pour ajuster la netteté des objectifs originaux des caméras V2.1 Raspberry Pi.
Cette pièce est ajustée et peut être maintenue dans les fenêtres de différentes boites existantes (comme celles mentionnées dans les liens suivants). Sinon, elle peut être aussi tenue manuellement.

http://www.thingiverse.com/thing:1738064
http://www.thingiverse.com/thing:685074
http://www.thingiverse.com/thing:1714796

The same tool remixed for Raspi Cams V1 is available under following link, thanks to antonydbzh :
Le même outil remixé pour des Raspi Cams V1 est disponible via le lien suivant, grâce à antonydbzh :
http://www.thingiverse.com/thing:1991636

# Print Settings

Printer: Dagoma Discovery 200
Rafts: No
Supports: No
Resolution: 0.2
Infill: 15-33%